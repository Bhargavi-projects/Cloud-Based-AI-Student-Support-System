# Cloud-Based AI Student Support System
This project includes speech-to-text, NLP concept extraction, story-based visuals,
AI chatbot for doubts, and grade analysis.
Run order:
1. transcribe.py
2. concept_extract.py
3. visual_story.py
4. chatbot.py
5. grade_analysis.py
